\set dbname ecommercedb
\set username userdb
