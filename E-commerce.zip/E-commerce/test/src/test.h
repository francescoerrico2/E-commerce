#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
#include <bits/stdc++.h>
using namespace std;


string generateRandomFirstName();

string generateRandomLastName();

string generateEmail(const char *nome, const char *cognome);

string generateRandomType();

string generateRandomPurchType();

string generateRandomPIva();

string generateRandomAzienda();

string generateRandomObjName();

string generateRandomBarCode();

float generatePrice();

