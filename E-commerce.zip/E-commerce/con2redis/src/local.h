#ifndef local_h
#define local_h

#include <stdio.h>
#include <stdlib.h>
#include <cstring>

#define DEBUG 1000000

void print_reply_types();

#endif
